package com.gnete.utils;

import java.io.IOException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.SimpleHttpConnectionManager;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.httpclient.protocol.Protocol;
import org.apache.commons.httpclient.protocol.ProtocolSocketFactory;

public class HttpClientV3Util {
	/**
	 * http����ʽ
	 * @param url
	 * @param xml_signed
	 * @return
	 * @throws Exception
	 */
	public static String httpRequest_sender(String url, String xml_signed) throws Exception   {


		String strResp = "";
		SimpleHttpConnectionManager conmgr = new SimpleHttpConnectionManager(true);
		HttpClient httpClient = new HttpClient(conmgr);
		PostMethod postMethod = new PostMethod(url);
		// ���ñ���
		httpClient.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "GBK");
		
		//�¼������
		ProtocolSocketFactory fcty = new MySecureProtocolSocketFactory();
		//������ص�https����ʽ
		Protocol.registerProtocol("https", new Protocol("https", fcty, 443));

		postMethod.setRequestBody(xml_signed);
		// ִ��getMethod
		try {
			long start = System.currentTimeMillis();
			// ִ��getMethod
			int statusCode = httpClient.executeMethod(postMethod);
			System.out.println("cost:" + (System.currentTimeMillis() - start));
			// ʧ��
			if (statusCode != HttpStatus.SC_OK) {
				System.out.println("Method failed: "+ postMethod.getStatusLine());
				// ��ȡ����
				byte[] responseBody = postMethod.getResponseBody();
				// ��������
				strResp = new String(responseBody, "GBK");
			} else {
				// ��ȡ����
				byte[] responseBody = postMethod.getResponseBody();
				strResp = new String(responseBody, "GBK");
			}
		} catch (HttpException e) {
			// �����������쳣��������Э�鲻�Ի��߷��ص�����������
			System.out.println("Please check your provided http address!");
			throw e;
		} catch (IOException e) {
			// ���������쳣
			System.out.println("Please check your net!");
			e.printStackTrace();
			throw e;
		} catch (Exception e) {
			throw e;
		} finally {
			// �ͷ�����
			postMethod.releaseConnection();
		}
		return strResp;
	}
	
	public static void main(String[] args) throws Exception{
		
		String url = "https://59.41.103.102/gzdsf/ProcessServlet";
		String retMsg = HttpClientV3Util.httpRequest_sender(url, "");
		System.out.println(retMsg);
	}
	
}


